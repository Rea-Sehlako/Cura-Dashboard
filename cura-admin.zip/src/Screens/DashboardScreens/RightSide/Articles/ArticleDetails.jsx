import React from "react";

export default function ArticleDetails() {
  return <div>ArticleDetails</div>;
}
