import React from "react";

export default function OrderDetails() {
  return <div>Orders</div>;
}
