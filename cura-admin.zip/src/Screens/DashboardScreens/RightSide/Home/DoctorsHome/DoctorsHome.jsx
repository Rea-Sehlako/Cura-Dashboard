import React from "react";

export default function DoctorsHome() {
  return <div>mm</div>;
}
