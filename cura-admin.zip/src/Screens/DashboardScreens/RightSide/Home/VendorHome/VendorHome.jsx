import React from "react";

export default function VendorHome() {
  return <div>VendorHome</div>;
}
