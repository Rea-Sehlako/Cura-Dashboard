import React from 'react'

export default function Appointments() {
  return (
    <div>Appointments</div>
  )
}
