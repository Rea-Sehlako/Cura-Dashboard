import React from 'react'

export default function Patients() {
  return (
    <div><h1>Patients</h1></div>
  )
}
