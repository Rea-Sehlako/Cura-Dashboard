import React from 'react'
import { Container } from 'react-bootstrap'

export default function DoctorRegisterSucess() {
  return (
    <Container>
        <h2>You appl</h2>
    </Container>
  )
}
