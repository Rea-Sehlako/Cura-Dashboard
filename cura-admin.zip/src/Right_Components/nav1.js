// import React from "react";
// import "./style.css";
// import Data from "./doctors.json";

// class Health extends Component{
//   render(){
//   return
//     <div class="sales-analytics">
//           <h2>Latest Articles</h2>
//           {/*<div class="item online">
//           <div class="icon">
//             <span class="material-icons-sharp">shopping cart</span>
//           </div>
//           <div class="right">
//             <div class="info">
//               <h3>Online Orders</h3>
//               <small class="text-muted">Last 24hrs</small>
//             </div>
//             <h5 class="success">+39%</h5>
//             <h3>34567</h3>
//           </div>
//         </div>
//         <div class="item offline"></div>
//           <div class="icon">
//             <span class="material-icons-sharp">local_mall</span>
//           </div>
//           <div class="right">
//             <div class="info">
//               <h3>Physical Orders</h3>
//               <small class="text-muted">Last 24hrs</small>
//             </div>
//             <h5 class="danger">-17%</h5>
//             <h3>56789</h3>
//           </div>
//           */}
//           <div>
//             {Data.map((data) => {
//               return (
//                 <div class="results" key={data.id}>
//                   <div class="profile-photo">
//                     <img src={logo} alt="Cura Logo" />
//                   </div>
//                   <div style={{ color: "black" }}>{data.name}</div>
//                   <div>{data.sales}</div>
//                   {data.revenue}
//                 </div>
//               );
//             })}
//           </div>
//           <div className="Button">
//             <button>View all products</button>
//           </div>
//         </div>

// }

// export default Health
