const doctorSpecialist = [
  { id: 1, label: "Cardiologist", value: "cardiologist" },
  { label: "Dentist", value: "dentist" },
  { label: "Dermatologist", value: "dermatologist" },
  { label: "Endocrinologist", value: "endocrinologist" },
  {
    label: "Gastroenterologist",
    value: "gastroenterologist",
  },
  {
    label: "General Practitioner",
    value: "general-practitioner",
  },
  { label: "Gynecologist", value: "gynecologist" },
  { label: "Neurologist", value: "neurologist" },
  { label: "Oncologist", value: "oncologist" },
  { label: "Ophthalmologist", value: "ophthalmologist" },
  {
    label: "Orthopedic Surgeon",
    value: "orthopedic-surgeon",
  },
  { label: "Pediatrician", value: "pediatrician" },
  { label: "Psychiatrist", value: "psychiatrist" },
  { label: "Pulmonologist", value: "pulmonologist" },
  { label: "Rheumatologist", value: "rheumatologist" },
  { label: "Urologist", value: "urologist" },
];

export default doctorSpecialist;
