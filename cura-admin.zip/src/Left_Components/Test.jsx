import React, {Component} from "react";
class Test extends Component{
  render(){
    return <div className="Test">
        <h1>Testing</h1>
        </div>
  }
}
export default Test