import React, {Component} from "react";

class Vendors extends Component{
  render(){
    return <a href="#">
    <span class="material-icons-sharp">memory</span>
    <h3>Vendors</h3>
  </a>
  }
}
export default Vendors