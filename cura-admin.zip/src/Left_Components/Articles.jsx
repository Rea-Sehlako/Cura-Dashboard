import React, {Component} from "react";

class Articles extends Component{
  render(){
    return <a href="#">
    <span class="material-icons-sharp">newspaper</span>
    <h3>Articles</h3>
  </a>
  }
}
export default Articles