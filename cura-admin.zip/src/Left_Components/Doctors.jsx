import React, {Component} from "react";

class Doctors extends Component{
  render(){
    return <a href="#">
    <span class="material-icons-sharp">vaccines</span>
    <h3>Doctors</h3>
  </a>
  }
}
export default Doctors