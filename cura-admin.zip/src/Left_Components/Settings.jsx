import React, {Component} from "react";

class Settings extends Component{
  render(){
    return <a href="#">
    <span class="material-icons-sharp">settings</span>
    <h3>Settings</h3>
  </a>
  }
}
export default Settings