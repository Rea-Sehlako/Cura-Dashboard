import React, {Component} from "react";

class Users extends Component{
  render(){
    return <a href="#">
    <span class="material-icons-sharp">person_outline</span>
    <h3>Users</h3>
  </a>
  }
}
export default Users