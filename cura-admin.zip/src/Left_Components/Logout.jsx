import React, {Component} from "react";

class Logout extends Component{
  render(){
    return <a href="#">
    <span class="material-icons-sharp">logout</span>
    <h3>Logout</h3>
  </a>
  }
}
export default Logout